import mysql.connector
import matplotlib.pyplot as plt

# Establish MySQL connection
connection = mysql.connector.connect(
    host='localhost',
    user='root',
    password='RootingItToTheBottomASAP6!',
    database='your_database'
)

cursor = connection.cursor()

try:
    # Define the business you want to plot
    business = 'book stores'


    # Define months (x-axis) and initialize sales_data (y-axis)
    months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov']
    sales_data = []

    # Construct the SQL query to retrieve monthly sales data for the specified business
    sql_query = f"""
        SELECT
            jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov
        FROM
            mstr_20
        WHERE
            Business = '{business}';
    """
    
    # Execute the SQL query
    cursor.execute(sql_query)
    
    # Fetch the result (should be only one row based on the WHERE condition)
    row = cursor.fetchone()

    if row:
        # Extract monthly sales data from the row
        sales_data = [value for value in row]  # Get all 11 months' sales data
        
        # Plotting the line graph
        plt.figure(figsize=(10, 6))
        plt.plot(months, sales_data, marker='o', linestyle='-', color='b')
        plt.title(f'Monthly Sales for {business}')
        plt.xlabel('Month')
        plt.ylabel('Sales')
        plt.grid(True)
        plt.xticks(rotation=45)
        plt.ylim(0, max(sales_data) + 1000)  # Adjust y-axis limits
        
        plt.show()
    else:
        print(f"No data found for '{business}'")

except mysql.connector.Error as error:
    print(f"Error: {error}")

finally:
    # Close cursor and connection
    cursor.close()
    connection.close()
