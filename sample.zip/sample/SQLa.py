import mysql.connector
import matplotlib.pyplot as plt

# Establish MySQL connection
connection = mysql.connector.connect(
    host='localhost',
    user='root',
    password='RootingItToTheBottomASAP6!',
    database='your_database'
)

cursor = connection.cursor()

try:
    # Define SQL query to retrieve monthly sales data for 'Retail and food services sales, total'
    sql_query = """
        SELECT
            jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov
        FROM
            mstr_20
        WHERE
            Business = 'Retail and food services sales, total';
    """
    
    # Execute the SQL query
    cursor.execute(sql_query)
    
    # Fetch the result (should be only one row based on the WHERE condition)
    row = cursor.fetchone()

    if row:
        # Extract monthly sales data from the row
        sales_data = [row[i] for i in range(11)]  # Extract sales data for 11 months (jan to nov)

        # Define the list of month names corresponding to the sales data
        months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov']

        # Determine the minimum value of sales_data
        min_sales = min(sales_data)

        # Plotting the line graph
        plt.figure(figsize=(10, 6))
        plt.plot(months, sales_data, marker='o', linestyle='-', color='b')
        plt.title('Monthly Sales for Retail and Food Services')
        plt.xlabel('Month')
        plt.ylabel('Sales')
        plt.grid(True)
        plt.xticks(rotation=45)
        
        # Set the lower limit of y-axis to the minimum sales value minus a buffer (e.g., 1000)
        plt.ylim(min_sales - 1000, max(sales_data) + 1000)

        plt.show()
    else:
        print("No data found for 'Retail and food services sales, total'")

except mysql.connector.Error as error:
    print(f"Error: {error}")

finally:
    # Close cursor and connection
    cursor.close()
    connection.close()
