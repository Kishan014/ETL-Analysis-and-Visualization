import csv
import mysql.connector

# Establish MySQL connection
connection = mysql.connector.connect(
    host='localhost',
    user='root',
    password='RootingItToTheBottomASAP6!',
    database='your_database'
)

cursor = connection.cursor()

# Create the table if it doesn't exist
csv_file_path = r'C:\Users\Kishan\Documents\MSTR_2020.csv'

try:
    with open(csv_file_path, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        
        for row in reader:
            business_id = int(row['Business_ID'])
            business_name = row['Business']
            
            # Convert each month's value to integer or None if NULL or empty
            def convert_to_int(value):
                if value and value != 'NULL':
                    return int(value.replace(',', ''))
                else:
                    return None
            
            jan_value = convert_to_int(row['Jan'])
            feb_value = convert_to_int(row['Feb'])
            mar_value = convert_to_int(row['Mar'])
            apr_value = convert_to_int(row['Apr'])
            may_value = convert_to_int(row['May'])
            jun_value = convert_to_int(row['Jun'])
            jul_value = convert_to_int(row['Jul'])
            aug_value = convert_to_int(row['Aug'])
            sep_value = convert_to_int(row['Sep'])
            oct_value = convert_to_int(row['Oct'])
            nov_value = convert_to_int(row['Nov'])
            dec_value = convert_to_int(row['Dec'])
            
            # Update the record if it already exists
            update_query = """
                UPDATE mstr_20
                SET Business = %s, Jan = %s, Feb = %s, Mar = %s, Apr = %s, May = %s, Jun = %s,
                    Jul = %s, Aug = %s, Sep = %s, Oct = %s, Nov = %s, `Dec` = %s
                WHERE Business_ID = %s
            """
            cursor.execute(update_query, (
                business_name,
                jan_value, feb_value, mar_value, apr_value, may_value, jun_value,
                jul_value, aug_value, sep_value, oct_value, nov_value, dec_value,
                business_id
            ))
            connection.commit()
    
    print("Data updated successfully!")

except FileNotFoundError:
    print(f"Error: CSV file not found at path '{csv_file_path}'.")

except mysql.connector.Error as error:
    print(f"Error updating data in table: {error}")

finally:
    if cursor:
        cursor.close()
    if connection:
        connection.close()